import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";

//assets
import tour360 from "../assets/360tour.svg";

//mui
import InputAdornment from "@mui/material/InputAdornment";
import OutlinedInput from "@mui/material/OutlinedInput";

//components
import TourDemoDiv from "../components/TourDemoDiv";
//api
import { useDispatch, useSelector } from "react-redux";
import { setAllTour } from "../slices/tourSlice";
import { useGetAllTourMutation } from "../slices/tourApiSlice";
//others
import { toast } from "react-toastify";
const Properties = () => {
  const dispatch = useDispatch();

  const [hashrender, setHashRender] = useState(false);
  let hash = window.location.hash;
  const navigate = useNavigate();
  const [getAllTours] = useGetAllTourMutation();
  const { tourInfo } = useSelector((state) => state.tour);

  const handleGetTours = async () => {
    try {
      const res = await getAllTours().unwrap();

      dispatch(setAllTour({ ...res }));
    } catch (error) {
      console.error(error);
      toast.error(error.msg);
    }
  };
  useEffect(() => {
    handleGetTours();
  }, []);
  console.log(tourInfo);
  return (
    <div id="properties">
      <h1 className="propertiesh1">Properties</h1>
      <div className="headerDiv">
        <Link to="#active" onClick={() => setHashRender(!hashrender)}>
          <p className={` ${hash === "#active" ? "linkpSelected" : "linkp"}`}>
            Active
          </p>
          <span
            className={` ${
              hash === "#active" ? "linkspanSelected" : "linkspan"
            }`}
          >
            {tourInfo?.length > 0
              ? tourInfo?.filter((tour) => tour.archived === false)?.length
              : "0"}{" "}
          </span>
        </Link>
        <h4>|</h4>
        <Link
          to="#archived"
          onClick={() => setHashRender(!hashrender)}
          style={{
            marginLeft: "0",
          }}
        >
          <p className={` ${hash === "#archived" ? "linkpSelected" : "linkp"}`}>
            Archived
          </p>
          <span
            className={` ${
              hash === "#archived" ? "linkspanSelected" : "linkspan"
            }`}
          >
            {tourInfo?.length > 0
              ? tourInfo?.filter((tour) => tour.archived === true)?.length
              : "0"}
          </span>
        </Link>
        <div className="searchDiv">
          <OutlinedInput
            id="outlined-adornment-weight"
            className="searchInput"
            placeholder="Ref. property"
            endAdornment={
              <InputAdornment position="end">
                <i className="fa-solid fa-magnifying-glass"></i>
              </InputAdornment>
            }
            aria-describedby="outlined-weight-helper-text"
            inputProps={{
              "aria-label": "weight",
            }}
          />
          <span className="downloadSpan">
            <i className="fa-solid fa-download"></i>
          </span>
        </div>
      </div>
      <div className="headerDiv headerDivMobile">
        <div className="searchDivMobile">
          <OutlinedInput
            id="outlined-adornment-weight"
            className="searchInput"
            placeholder="Ref. property"
            endAdornment={
              <InputAdornment position="end">
                <i className="fa-solid fa-magnifying-glass"></i>
              </InputAdornment>
            }
            aria-describedby="outlined-weight-helper-text"
            inputProps={{
              "aria-label": "weight",
            }}
          />
          <span className="downloadSpan">
            <i className="fa-solid fa-download"></i>
          </span>
        </div>
      </div>

      <div className="tourDiv">
        <div
          className="newTourDiv"
          onClick={() => navigate("/home")}
          style={{
            display: `${hash === "#active" ? "flex" : "none"}`,
          }}
        >
          <img src={tour360} alt="" className="worldImg" />
          <p>Create new tour</p>
        </div>
        {tourInfo?.length > 0 && window.location.hash === "#active"
          ? tourInfo
              ?.filter((tour) => tour.archived === false)
              .map((tour, index) => <TourDemoDiv tour={tour} key={index} />)
          : tourInfo?.length > 0 && window.location.hash === "#archived"
          ? tourInfo
              ?.filter((tour) => tour.archived === true)
              .map((tour, index) => <TourDemoDiv tour={tour} key={index} />)
          : "No tours found"}
      </div>
      <div className="resultDiv">
        <p>
          Showing{" "}
          {tourInfo?.length > 0 && window.location.hash === "#active"
            ? tourInfo?.filter((tour) => tour.archived === false)?.length
            : tourInfo?.length > 0 &&
              window.location.hash === "#archived" &&
              tourInfo?.filter((tour) => tour.archived === true)?.length}{" "}
          results
        </p>
      </div>
    </div>
  );
};

export default Properties;
