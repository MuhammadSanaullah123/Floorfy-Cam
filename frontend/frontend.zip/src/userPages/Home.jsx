import React from "react";
import Sidebar from "../components/Sidebar";
const Home = () => {
  return (
    <div>
      <Sidebar />

      <div id="home">
        <span className="numberDiv">
          <h1>1</h1>
        </span>
      </div>
    </div>
  );
};

export default Home;
